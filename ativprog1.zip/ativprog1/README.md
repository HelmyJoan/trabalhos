# ativprog1
 Curriculo de Bill Gates
